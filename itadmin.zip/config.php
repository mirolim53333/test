<?php
// Ma'lumotlar bazasi sozlamalari
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "it_wiki";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("SET NAMES utf8mb4");
} catch(PDOException $e) {
    die("Ulanishda xato: " . $e->getMessage());
}
?>