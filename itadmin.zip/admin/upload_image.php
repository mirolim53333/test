<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['upload'])) {
    $uploadResult = uploadImage($_FILES['upload']);
    if (isset($uploadResult['error'])) {
        http_response_code(400);
        echo json_encode(['error' => $uploadResult['error']]);
    } else {
        $baseUrl = 'D:/OSPanel/domains/your-domain/admin/uploads/';
        $relativePath = str_replace('D:/OSPanel/domains/your-domain/', '', $uploadResult['path']);
        echo json_encode(['url' => $baseUrl . $relativePath]);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'No file uploaded or invalid request']);
}
?>