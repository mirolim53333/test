<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitizeInput($_POST['name']);

    $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (:name)");
    $stmt->execute(['name' => $name]);
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategoriya qo'shish - Bank AI Wiki</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <h1 class="logo">Bank AI Wiki</h1>
                <nav class="navbar navbar-expand-lg">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="../index.php">Bosh sahifa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../history.php">Tarix</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="index.php">Admin Paneli</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="logout.php">Chiqish</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <div class="container mt-4">
        <h2>Kategoriya qo'shish</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="name" class="form-label">Kategoriya nomi</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Qo'shish</button>
            <a href="index.php" class="btn btn-secondary">Orqaga</a>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>