<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT image_path FROM articles WHERE id = :id");
$stmt->execute(['id' => $id]);
$article = $stmt->fetch(PDO::FETCH_ASSOC);

if ($article['image_path'] && file_exists("../{$article['image_path']}")) {
    unlink("../{$article['image_path']}");
}

$stmt = $conn->prepare("DELETE FROM articles WHERE id = :id");
$stmt->execute(['id' => $id]);
header("Location: index.php");
exit();
?>