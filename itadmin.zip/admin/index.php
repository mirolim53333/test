<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli - Bank AI Wiki</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <h1 class="logo">Bank AI Wiki</h1>
                <nav class="navbar navbar-expand-lg">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="../index.php">Bosh sahifa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../history.php">Tarix</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="index.php">Admin Paneli</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="logout.php">Chiqish</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <div class="container mt-4">
        <h2>Admin Paneli</h2>

        <!-- Kategoriyalarni boshqarish -->
        <h3>Kategoriyalarni boshqarish</h3>
        <form method="POST" action="add_category.php" class="mb-4">
            <div class="mb-3">
                <label for="name" class="form-label">Kategoriya nomi</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Qo'shish</button>
        </form>
        <table class="table table-bordered mb-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nomi</th>
                    <th>Amallar</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $conn->query("SELECT id, name FROM categories");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . sanitizeInput($row['name']) . "</td>";
                    echo "<td>
                        <a href='edit_category.php?id=" . $row['id'] . "' class='btn btn-sm btn-warning'>Tahrirlash</a>
                        <a href='delete_category.php?id=" . $row['id'] . "' class='btn btn-sm btn-danger' onclick='return confirm(\"O\'chirishni tasdiqlaysizmi?\")'>O\'chirish</a>
                    </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Maqolalarni boshqarish -->
        <h3>Maqolalarni boshqarish</h3>
        <a href="add_article.php" class="btn btn-primary mb-3">Yangi maqola qo'shish</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Sarlavha</th>
                    <th>Kategoriya</th>
                    <th>Mazmun</th>
                    <th>Rasm</th>
                    <th>Amallar</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $conn->query("SELECT a.id, a.title, a.content, a.image_path, c.name AS category_name 
                                     FROM articles a 
                                     LEFT JOIN categories c ON a.category_id = c.id");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . sanitizeInput($row['title']) . "</td>";
                    echo "<td>" . sanitizeInput($row['category_name']) . "</td>";
                    echo "<td>" . sanitizeInput(substr(strip_tags($row['content']), 0, 100)) . "...</td>";
                    echo "<td>";
                    if ($row['image_path']) {
                        echo "<img src='../" . sanitizeInput($row['/uploads/']) . "' alt='Maqola rasmi' class='table-image'>";
                    } else {
                        echo "Rasm yo'q";
                    }
                    echo "</td>";
                    echo "<td>
                        <a href='edit_article.php?id=" . $row['id'] . "' class='btn btn-sm btn-warning'>Tahrirlash</a>
                        <a href='delete_article.php?id=" . $row['id'] . "' class='btn btn-sm btn-danger' onclick='return confirm(\"O\'chirishni tasdiqlaysizmi?\")'>O\'chirish</a>
                    </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Foydalanuvchi tarixi -->
        <h3>Foydalanuvchi tarixi</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Foydalanuvchi</th>
                    <th>Savol</th>
                    <th>Javob</th>
                    <th>Sana</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $conn->query("SELECT h.user_id, u.username, h.question, h.response, h.created_at 
                                     FROM history h 
                                     LEFT JOIN users u ON h.user_id = u.id 
                                     ORDER BY h.created_at DESC");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>" . ($row['username'] ? sanitizeInput($row['username']) : 'Anonim') . "</td>";
                    echo "<td>" . sanitizeInput($row['question']) . "</td>";
                    echo "<td>" . sanitizeInput(substr(strip_tags($row['response']), 0, 100)) . "...</td>";
                    echo "<td>" . $row['created_at'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>