<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = sanitizeInput($_POST['title']);
    $content = $_POST['content'];
    $category_id = $_POST['category_id'];
    $image_path = null;

    if (isset($_FILES['upload']) && $_FILES['upload']['size'] > 0) {
        $uploadResult = uploadImage($_FILES['upload']);
        if (isset($uploadResult['error'])) {
            $error = $uploadResult['error'];
        } else {
            $image_path = $uploadResult['path'];
        }
    }

    if (!isset($error)) {
        $stmt = $conn->prepare("INSERT INTO articles (title, content, category_id, image_path) 
                               VALUES (:title, :content, :category_id, :image_path)");
        $stmt->execute([
            'title' => $title,
            'content' => $content,
            'category_id' => $category_id,
            'image_path' => $image_path
        ]);
        header("Location: index.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maqola qo'shish - Bank AI Wiki</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <script src="/ckeditor5/ckeditor5.js"></script> <!-- Build 
    papkasiga yo'naltirish -->
    <script src="https://cdn.ckeditor.com/ckeditor5/41.0.0/classic/ckeditor.js"></script>

</head>
<body>
    <header class="header">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <h1 class="logo">Bank AI Wiki</h1>
                <nav class="navbar navbar-expand-lg">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="../index.php">Bosh sahifa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../history.php">Tarix</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="index.php">Admin Paneli</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="logout.php">Chiqish</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <div class="container mt-4">
        <h2>Maqola qo'shish</h2>
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="title" class="form-label">Sarlavha</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="category_id" class="form-label">Kategoriya</label>
                <select name="category_id" class="form-select" required>
                    <option value="">Kategoriyani tanlang</option>
                    <?php
                    $stmt = $conn->query("SELECT id, name FROM categories");
                    while ($category = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo "<option value='{$category['id']}'>" . sanitizeInput($category['name']) . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">Mazmun</label>
                <textarea name="content" id="content" class="form-control" rows="10"></textarea>
            </div>
            <div class="mb-3">
                <label for="upload" class="form-label">Rasm (ixtiyoriy)</label>
                <input type="file" name="upload" class="form-control" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Qo'shish</button>
            <a href="index.php" class="btn btn-secondary">Orqaga</a>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            ClassicEditor
                .create(document.querySelector('#content'), {
                    toolbar: [
                        'heading', '|',
                        'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|',
                        'outdent', 'indent', '|',
                        'imageUpload', 'blockQuote', 'insertTable', 'mediaEmbed', 'undo', 'redo'
                    ],
                    image: {
                        toolbar: [
                            'imageStyle:inline',
                            'imageStyle:block',
                            'imageStyle:side',
                            '|',
                            'toggleImageCaption',
                            'imageTextAlternative'
                        ]
                    },
                    simpleUpload: {
                        uploadUrl: 'upload_image.php'
                    }
                })
                .then(editor => {
                    console.log('Editor initialized', editor);
                })
                .catch(error => {
                    console.error('Editor initialization error:', error);
                });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        ClassicEditor
            .create(document.querySelector('#content'), {
                toolbar: [
                    'heading', '|',
                    'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|',
                    'outdent', 'indent', '|',
                    'blockQuote', 'insertTable', 'mediaEmbed', 'undo', 'redo'
                ],
                language: 'uz' // O‘zbek tili uchun
            })
            .then(editor => {
                console.log('Editor ishga tushdi', editor);
            })
            .catch(error => {
                console.error('Xato:', error);
            });
    });
</script>
</body>
</html>