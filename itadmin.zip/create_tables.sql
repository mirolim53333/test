CREATE DATABASE IF NOT EXISTS bank_ai_wiki;
USE bank_ai_wiki;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    is_admin TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category_id INT,
    image_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

CREATE TABLE history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT 0,
    question TEXT NOT NULL,
    response TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

INSERT INTO categories (name) VALUES
('Bank xizmatlari'), ('AI texnologiyalari'), ('Dasturlash');

INSERT INTO articles (title, content, category_id, image_path) VALUES
('AI bank sohasida', '<p>AI bank xizmatlarida kredit tahlili, firibgarlikni aniqlash va mijozlarga xizmat ko\'rsatishda qo\'llaniladi.</p>', 2, 'uploads/ai_bank.jpg'),
('Kredit turlari', '<p>Kredit turlari: iste\'mol, ipoteka, biznes kreditlari.</p>', 1, NULL);

INSERT INTO users (username, password, is_admin) VALUES
('admin', '$2y$10$1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y6z', 1);