<?php
// Umumiy funksiyalar
function analyzeQuestion($question) {
    $question = trim($question ?? ''); // Null bo'lsa bo'sh string qaytaradi
    if (empty($question)) {
        return [];
    }
    $question = strtolower($question);
    $stopWords = ['nima', 'qanday', 'bu', 'haqida', 'qilish', 'uchun'];
    $keywords = array_diff(explode(" ", $question), $stopWords);
    return array_filter($keywords, function($word) { return strlen(trim($word)) > 2; });
}

function sanitizeInput($input) {
    $input = trim($input ?? ''); // Null bo'lsa bo'sh string qaytaradi
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

function uploadImage($file) {
    $targetDir = __DIR__ . '/uploads/'; // Hozirgi papkaning ichidagi uploads/ papkasiga yo'l
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    $fileName = basename($file["name"]);
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $uniqueName = uniqid() . "." . $fileType;
    $targetPath = $targetDir . $uniqueName;

    // MIME turi tekshiruvi
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file["tmp_name"]);
    finfo_close($finfo);
    $allowedMimes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!in_array($mime, $allowedMimes)) {
        return ["error" => "Faqat JPG, JPEG, PNG yoki GIF fayllar ruxsat etiladi."];
    }

    // Hajm tekshiruvi
    if ($file["size"] > $maxSize) {
        return ["error" => "Fayl hajmi 5MB dan kichik bo'lishi kerak."];
    }

    // Faylni ko'chirish
    if (move_uploaded_file($file["tmp_name"], $targetPath)) {
        // Windows uchun yo'lni to'g'rilash (slashlarni almashtirish)
        $targetPath = str_replace('\\', '/', $targetPath);
        // Web uchun relative yo'l qaytarish
        $webPath = '/uploads/' . $uniqueName;
        return ["path" => $webPath];
    } else {
        // Xatolikni aniqlash uchun log qo'shish
        $errorMsg = "Fayl ko'chirishda xato. Yo'l: $targetPath, Ruxsatlar: " . var_export(stat($targetDir), true);
        file_put_contents(__DIR__ . '/upload_error.log', date('Y-m-d H:i:s') . " - $errorMsg\n", FILE_APPEND);
        return ["error" => "Fayl yuklashda xato. Papka ruxsatlarini tekshiring."];
    }
}
?>