<?php
session_start();
require_once 'config.php';
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tarix - Bank AI Wiki</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <h1 class="logo">Bank AI Wiki</h1>
                <nav class="navbar navbar-expand-lg">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Bosh sahifa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="history.php">Tarix</a>
                                </li>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="logout.php">Chiqish</a>
                                    </li>
                                <?php else: ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="login.php">Kirish</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="register.php">Ro'yxatdan o'tish</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (isset($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="admin/index.php">Admin Paneli</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <div class="container mt-4">
        <h2>Savollar tarixi</h2>
        <div class="history">
            <?php
            $stmt = $conn->prepare("SELECT question, response, created_at 
                                   FROM history 
                                   WHERE user_id = :user_id 
                                   ORDER BY created_at DESC");
            $stmt->execute(['user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0]);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($history)) {
                echo "<div class='alert alert-info'>Hozircha savollar tarixi yo'q.</div>";
            } else {
                foreach ($history as $item) {
                    echo "<div class='history-item'>";
                    echo "<strong>Savol:</strong> " . sanitizeInput($item['question']) . "<br>";
                    echo "<strong>Javob:</strong> " . $item['response'] . "<br>";
                    echo "<small>" . $item['created_at'] . "</small>";
                    echo "</div>";
                }
            }
            ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>