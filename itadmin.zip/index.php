<?php
session_start();
require_once 'config.php';
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Bank AI Wiki - Bank va texnologiya bo'yicha savollaringizga javob toping">
    <meta name="keywords" content="bank, AI, dasturlash, ma'lumotlar bazasi, tarmoqlar">
    <title>Bank AI Wiki</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <style>
        .sidebar-left, .sidebar-right {
            width: 20%;
            position: fixed;
            top: 108px;
            bottom: 0;
            padding: 20px;
            background: linear-gradient(135deg, #e0e7ff 0%, #c3cfe2 100%);
            overflow-y: auto;
            transition: all 0.3s ease;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }
        .sidebar-left { left: 0; }
        .sidebar-right { right: 0; }
        .chat-container {
            margin-left: 21%;
            margin-right: 20%;
            padding: 20px;
            transition: all 0.3s ease;
        }
        .response-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .response h3 {
            margin: 0;
            font-size: 1.5rem;
        }
        .response-image {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
            object-fit: cover;
            margin-left: 15px;
        }
        .read-more {
            cursor: pointer;
            color: #2563eb;
            margin-left: 5px;
            text-decoration: underline;
        }
        .full-text {
            display: none;
        }
        @media (max-width: 768px) {
            .sidebar-left, .sidebar-right { display: none; }
            .chat-container { margin: 20px 0; padding: 15px; max-width: 100%; }
            .question-box .input-group { flex-direction: column; gap: 10px; }
            .question-box input, .question-box button { width: 100%; }
            .response-header { flex-direction: column; align-items: flex-start; }
            .response-image { max-width: 80px; margin: 10px 0; }
            .response h3 { font-size: 1.2rem; }
            .category-filter .form-select { max-width: 100%; }
            .header .navbar-nav { flex-direction: column; text-align: center; }
            .header .navbar-collapse { position: absolute; top: 100%; left: 0; right: 0; background: #1e3a8a; padding: 10px; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); }
            .header .nav-link { padding: 10px 0; color: #ffffff !important; }
        }
        @media (min-width: 769px) and (max-width: 1200px) {
            .sidebar-left, .sidebar-right { width: 15%; }
            .chat-container { margin-left: 15%; margin-right: 15%; }
            .response-image { max-width: 90px; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <h1 class="logo">Bank AI Wiki</h1>
                <nav class="navbar navbar-expand-lg">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link active" href="index.php">Bosh sahifa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="history.php">Tarix</a>
                                </li>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="logout.php">Chiqish</a>
                                    </li>
                                <?php else: ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="login.php">Kirish</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="register.php">Ro'yxatdan o'tish</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (isset($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="admin/index.php">Admin Paneli</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <div class="sidebar-left">
        <h4>Savollar tarixi</h4>
        <ul class="list-group">
            <?php
            $stmt = $conn->prepare("SELECT question, created_at 
                                   FROM history 
                                   WHERE user_id = :user_id 
                                   ORDER BY created_at DESC 
                                   LIMIT 5");
            $stmt->execute(['user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0]);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (empty($history)) {
                echo "<div class='alert alert-info'>Hozircha savollar tarixi yo'q.</div>";
            } else {
                foreach ($history as $item) {
                    echo "<li class='list-group-item'>" . sanitizeInput($item['question']) . " (" . $item['created_at'] . ")</li>";
                }
            }
            ?>
        </ul>
    </div>
    <div class="sidebar-right">
        <h4>Ko'p so'raladigan savollar</h4>
        <ul class="list-group">
            <li class="list-group-item">Qanday qilib maqola qidiraman?</li>
            <li class="list-group-item">Ma'lumot qayerdan keladi?</li>
            <li class="list-group-item">Yordam uchun kim bilan bog'lanaman?</li>
        </ul>
    </div>
    <div class="chat-container">
        <div class="category-filter">
            <form method="GET" action="">
                <select name="category_id" class="form-select" onchange="this.form.submit()">
                    <option value="">Barcha kategoriyalar</option>
                    <?php
                    $stmt = $conn->query("SELECT id, name FROM categories");
                    while ($category = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $selected = isset($_GET['category_id']) && $_GET['category_id'] == $category['id'] ? 'selected' : '';
                        echo "<option value='{$category['id']}' $selected>" . sanitizeInput($category['name']) . "</option>";
                    }
                    ?>
                </select>
            </form>
        </div>
        <div class="question-box">
            <form method="POST" action="">
                <div class="input-group">
                    <input type="text" name="question" class="form-control" placeholder="Savolingizni kiriting..." required>
                    <button type="submit" class="btn btn-primary">Yuborish</button>
                </div>
            </form>
        </div>
        <div class="response">
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $question = sanitizeInput($_POST['question']);
                $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;

                $keywords = analyzeQuestion($question);
                if (empty($keywords)) {
                    echo "<div class='alert alert-warning'>Iltimos, aniqroq savol bering.</div>";
                } else {
                    $sql = "SELECT a.id, a.title, a.content, a.image_path, c.name AS category_name 
                            FROM articles a 
                            LEFT JOIN categories c ON a.category_id = c.id 
                            WHERE ";
                    $conditions = [];
                    foreach ($keywords as $keyword) {
                        $conditions[] = "LOWER(a.content) LIKE :keyword_$keyword OR LOWER(a.title) LIKE :keyword_$keyword";
                    }
                    $sql .= implode(" OR ", $conditions);
                    if (isset($_GET['category_id']) && !empty($_GET['category_id'])) {
                        $sql .= " AND a.category_id = :category_id";
                    }

                    try {
                        $stmt = $conn->prepare($sql);
                        foreach ($keywords as $keyword) {
                            $stmt->bindValue(":keyword_$keyword", "%$keyword%");
                        }
                        if (isset($_GET['category_id']) && !empty($_GET['category_id'])) {
                            $stmt->bindValue(":category_id", $_GET['category_id'], PDO::PARAM_INT);
                        }
                        $stmt->execute();
                        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

                        $response_text = $results ? "" : "<div class='alert alert-info'>Hech qanday ma'lumot topilmadi.</div>";
                        if ($results) {
                            foreach ($results as $result) {
                                $shortContent = mb_substr(strip_tags($result['content']), 0, 200) . '...';
                                $fullContent = $result['content'];
                                echo "<div class='response-header'>";
                                echo "<h3>" . sanitizeInput($result['title']) . " (" . htmlspecialchars($result['category_name']) . ")</h3>";
                                if ($result['image_path']) {
                                    $imageUrl = 'http://itadmin.xb.uz/uploads/' . basename(sanitizeInput($result['image_path']));
                                    if (file_exists('D:/OSPanel/domains/itadmin.xb.uz/uploads/' . basename(sanitizeInput($result['image_path'])))) {
                                        echo "<img src='$imageUrl' alt='Maqola rasmi' class='response-image'>";
                                    } else {
                                        echo "<div class='alert alert-warning'>Rasm topilmadi: $imageUrl</div>";
                                    }
                                }
                                echo "</div>";
                                if (strlen(strip_tags($fullContent)) > 200) {
                                    echo "<span class='short-text'>" . $shortContent . "</span>";
                                    echo "<span class='full-text' style='display:none;'>" . $fullContent . "</span>";
                                    echo "<span class='read-more' data-id='" . ($result['id'] ?? '0') . "'>Batafsil o'qish</span>";
                                } else {
                                    echo "<div>" . $fullContent . "</div>";
                                }
                            }
                        }
                        echo $response_text;

                        $stmt = $conn->prepare("INSERT INTO history (user_id, question, response, created_at) 
                                               VALUES (:user_id, :question, :response, NOW())");
                        $stmt->execute(['user_id' => $user_id, 'question' => $question, 'response' => $response_text]);
                    } catch(PDOException $e) {
                        echo "<div class='alert alert-danger'>Xato: " . $e->getMessage() . "</div>";
                    }
                }
            }
            ?>
        </div>
        <div class="history" style="display:none;">
            <h4>Savollar tarixi</h4>
            <?php
            $stmt = $conn->prepare("SELECT question, response, created_at 
                                   FROM history 
                                   WHERE user_id = :user_id 
                                   ORDER BY created_at DESC 
                                   LIMIT 10");
            $stmt->execute(['user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0]);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (empty($history)) {
                echo "<div class='alert alert-info'>Hozircha savollar tarixi yo'q.</div>";
            } else {
                foreach ($history as $item) {
                    echo "<div class='history-item'>";
                    echo "<strong>Savol:</strong> " . sanitizeInput($item['question']) . "<br>";
                    echo "<strong>Javob:</strong> " . $item['response'] . "<br>";
                    echo "<small>" . $item['created_at'] . "</small>";
                    echo "</div>";
                }
            }
            ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.read-more').forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const shortText = this.previousElementSibling;
                    const fullText = shortText.nextElementSibling;
                    if (fullText.style.display === 'none') {
                        shortText.style.display = 'none';
                        fullText.style.display = 'inline';
                        this.textContent = 'Yopish';
                    } else {
                        fullText.style.display = 'none';
                        shortText.style.display = 'inline';
                        this.textContent = 'Batafsil o'qish';
                    }
                });
            });
        });
    </script>
</body>
</html>